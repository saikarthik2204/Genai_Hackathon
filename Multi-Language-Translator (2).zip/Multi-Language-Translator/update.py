# First, let's create a dictionary of the new idioms and their corrections
new_idioms = {
    "I won't be able to make it to the meeting; I'm feeling a bit under the weather today": "I won't be able to make it to the meeting; I'm feeling a bit sick today",
    "Unclogging my sink was a piece of cake for Carlita. She's a plumber": "Unclogging my sink was very easy for Carlita. She's a plumber",
    "Please stop beating around the bush and tell me what happened": "Please stop avoiding the main point and tell me what happened",
    "To face a difficult situation with courage": "To handle a difficult situation bravely",
    "Work from home turned into a blessing in disguise for many as they could spend quality time with their family": "Work from home turned into an unexpected benefit for many as they could spend quality time with their family",
    "They really cut corners when they built this bathroom": "They really did poor quality work to save money when they built this bathroom",
    "Going into space on Jeff Bezos' rocket will cost you an arm and a leg": "Going into space on Jeff Bezos' rocket will cost you a lot of money",
    "Relax, I'm just pulling your leg!": "Relax, I'm just joking with you!",
    "Prematurely reveal confidential information": "Accidentally or intentionally reveal secret information before the proper time",
    "Happens very rarely": "Occurs extremely infrequently",
    "To work late into the night or to work hard on something": "To stay up late working or studying",
    "By agreeing to do two big projects at once, I bit off more than I could chew": "By agreeing to do two big projects at once, I took on more responsibility than I could handle"
}

def update_input_file(new_idioms):
    try:
        # Read existing content
        try:
            with open('input.txt', 'r', encoding='utf-8') as file:
                existing_content = file.read().strip().split('\n')
        except FileNotFoundError:
            existing_content = []

        # Convert existing content to dictionary
        existing_dict = {}
        for line in existing_content:
            if '=>' in line:
                key, value = line.split('=>')
                existing_dict[key.strip()] = value.strip()

        # Update with new idioms
        existing_dict.update(new_idioms)

        # Write back to file
        with open('input.txt', 'w', encoding='utf-8') as file:
            for key, value in existing_dict.items():
                file.write(f"{key} => {value}\n")
            
        print("Successfully updated input.txt with new idioms")
        
    except Exception as e:
        print(f"Error updating file: {e}")

# Run the update
update_input_file(new_idioms)