from flask import Flask, request, jsonify, render_template
from transformers import pipeline
from textblob import TextBlob
from langdetect import detect
import re
from googletrans import Translator

app = Flask(__name__)

# Initialize Emotion Classifier
emotion_classifier = pipeline(
    "text-classification",
    model="j-hartmann/emotion-english-distilroberta-base",
    return_all_scores=True
)

# Common Idioms Dictionary
IDIOMS = {
    "raining cats and dogs": "raining heavily",
    "under the weather": "feeling sick",
    "piece of cake": "very easy",
    "break a leg": "good luck",
    "apple of my eye": "favorite person",
    "cost an arm and a leg": "very expensive",
    "beat around the bush": "avoid saying something directly",
    "bite the bullet": "face a difficult situation bravely",
    "blessing in disguise": "something good that seemed bad at first",
    "cut corners": "do something in the easiest or cheapest way",
    "pull someone's leg": "joke with someone",
    "spill the beans": "reveal a secret",
    "once in a blue moon": "very rarely",
    "burn the midnight oil": "work late into the night",
    "bite off more than you can chew": "take on more than you can handle",
    "hit the nail on the head": "describe exactly what is causing a situation",
    "let the cat out of the bag": "reveal a secret accidentally",
    "cold feet": "become nervous",
    "get the ball rolling": "start something",
    "hang in there": "don't give up",
    "hit the books": "study hard",
    "miss the boat": "miss an opportunity",
    "on cloud nine": "very happy",
    "speak of the devil": "person appears when being talked about",
    "straight from the horse's mouth": "information from the original source",
    "add fuel to the fire": "make a bad situation worse",
    "bark up the wrong tree": "look for solutions in the wrong place",
    "bite the dust": "fail or die",
    "break the ice": "make people feel more comfortable",
    "call it a day": "stop working on something"
}

# Load Corrections from input.txt
def load_corrections():
    corrections = {}
    try:
        with open("input.txt", "r", encoding="utf-8") as file:
            for line in file:
                if "=>" in line:
                    wrong, correct = line.strip().split("=>")
                    corrections[wrong.strip().lower()] = correct.strip()
    except FileNotFoundError:
        print("⚠️ input.txt not found")
    return corrections

# Combine built-in idioms with custom corrections
def get_all_corrections():
    custom_corrections = load_corrections()
    all_corrections = IDIOMS.copy()
    all_corrections.update(custom_corrections)
    return all_corrections

# Initialize corrections and translator
CORRECTIONS = get_all_corrections()
translator = Translator()

def get_emotion(text):
    """Detect emotion in text"""
    emotions = emotion_classifier(text)[0]
    context_emotions = [e for e in emotions if e['score'] > 0.1]
    if context_emotions:
        return max(context_emotions, key=lambda x: x['score'])['label']
    return "neutral"

def preprocess_text(text):
    """Clean and normalize text"""
    text = text.strip()
    text = re.sub(r'\s+', ' ', text)
    text = text.capitalize()
    return text

def find_and_replace_idioms(text):
    """Find and replace idioms in text while preserving case"""
    text_lower = text.lower()
    result = text
    found_idioms = []
    
    for idiom, meaning in CORRECTIONS.items():
        if idiom in text_lower:
            # Use regex to replace while preserving case
            pattern = re.compile(re.escape(idiom), re.IGNORECASE)
            result = pattern.sub(meaning, result)
            found_idioms.append({"idiom": idiom, "meaning": meaning})
            
    return result, found_idioms

def translate_text(text, target_lang):
    """Translate text using Google Translate"""
    try:
        if target_lang == 'en':
            return text
        return translator.translate(text, dest=target_lang).text
    except Exception as e:
        print(f"⚠️ Translation Error: {e}")
        return text

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/process', methods=['POST'])
def process_text():
    try:
        data = request.json
        if not data or 'text' not in data:
            return jsonify({'error': 'No text provided'}), 400

        # Get input text and target language
        text = preprocess_text(data['text'])
        target_lang = data.get('target_lang', 'en')

        # Find and replace idioms
        corrected_text, found_idioms = find_and_replace_idioms(text)

        # Get emotion of corrected text
        emotion = get_emotion(corrected_text)

        # Translate the corrected text
        translated_text = translate_text(corrected_text, target_lang)

        return jsonify({
            'original': text,
            'corrected': corrected_text,
            'emotion': emotion,
            'translated': translated_text,
            'idioms_found': found_idioms
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)