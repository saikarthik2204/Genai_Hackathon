import re
import pandas as pd
import requests
from flask import Flask, request, jsonify, render_template
from transformers import pipeline, AutoModelForSeq2SeqLM, AutoTokenizer
from textblob import TextBlob
from langdetect import detect
from huggingface_hub import login  # Updated import

app = Flask(__name__)

# Hugging Face API Key (Replace with your key)
HF_TRANSLATE_URL = "https://api-inference.huggingface.co/models/Helsinki-NLP/opus-mt-en-hi"
HF_HEADERS = {"Authorization": "Bearer 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"}

# Load Emotion Detection Model
emotion_classifier = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base", return_all_scores=True)

# Load Translation Model (for multiple languages)
MODEL_MAP = {
    "hi": "Helsinki-NLP/opus-mt-en-hi",
    "te": "Helsinki-NLP/opus-mt-en-te",
    "bn": "Helsinki-NLP/opus-mt-en-bn",
    "ta": "Helsinki-NLP/opus-mt-en-ta",
    "kn": "Helsinki-NLP/opus-mt-en-kn",
}

# Authenticate with Hugging Face if necessary
login(token="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")

# Check model availability and load tokenizers and models
TOKENIZERS = {}
MODELS = {}
for lang, model in MODEL_MAP.items():
    try:
        TOKENIZERS[lang] = AutoTokenizer.from_pretrained(model)
        MODELS[lang] = AutoModelForSeq2SeqLM.from_pretrained(model)
    except EnvironmentError as e:
        print(f"⚠️ Error loading model {model}: {e}")

# Language Mapping
LANG_MAP = {"en": "eng_Latn", "hi": "hin_Deva", "te": "tel_Telu", "bn": "ben_Beng", "ta": "tam_Taml", "kn": "kan_Knda"}

# Load Custom Corrections from input.txt
def load_corrections():
    corrections = {}
    try:
        with open("input.txt", "r", encoding="utf-8") as file:
            for line in file:
                if "=>" in line:
                    wrong, correct = line.strip().split("=>")
                    corrections[wrong.strip().lower()] = correct.strip()
    except FileNotFoundError:
        print("⚠️ input.txt not found, skipping...")
    return corrections

# Load Telugu Slang Corrections from CSV
def load_slang_corrections():
    slang_dict = {}
    try:
        df = pd.read_csv("large_telugu_slang_dataset.csv")
        for _, row in df.iterrows():
            slang_dict[row["slang"].strip().lower()] = row["corrected"].strip()
    except Exception as e:
        print(f"⚠️ Error loading Telugu slang dataset: {e}")
    return slang_dict

# Load both datasets
CORRECTIONS = load_corrections()
SLANG_CORRECTIONS = load_slang_corrections()

# Clean Text Function
def clean_text(text):
    text = re.sub(r"\s+", " ", text)  # Remove extra spaces
    text = re.sub(r"[^a-zA-Z0-9.,!?' ]+", " ", text)  # Keep basic punctuation
    return text.strip()

# Auto-correct Function
def auto_correct(text):
    return str(TextBlob(text).correct())

# Detect Language Function
def detect_language(text):
    try:
        return detect(text)
    except:
        return "en"  # Default to English

# Emotion Detection Function
def detect_emotion(text):
    emotions = emotion_classifier(text)
    return max(emotions[0], key=lambda x: x['score'])['label']

# Context-aware Translation Function
def context_translate(text, src_lang="en", tgt_lang="hi"):
    if tgt_lang not in MODEL_MAP:
        return text  # Return original if translation model is not available

    tokenizer = TOKENIZERS.get(tgt_lang)
    model = MODELS.get(tgt_lang)

    if not tokenizer or not model:
        return text  # Return original if tokenizer or model is not available

    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)
    outputs = model.generate(**inputs)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

# Flask API Route for JSON Response with Multi-language Support
@app.route("/api/correct", methods=["POST"])
def correct_text():
    try:
        data = request.json
        user_text = data.get("text", "").strip()
        target_lang = data.get("target_lang", "hi")  # Default to Hindi

        if not user_text:
            return jsonify({"error": "Text is required"}), 400

        # Check for predefined corrections or slang corrections
        corrected_text = CORRECTIONS.get(user_text.lower(), SLANG_CORRECTIONS.get(user_text.lower(), user_text))

        # Auto-correct if no predefined correction found
        if corrected_text == user_text:
            corrected_text = auto_correct(user_text)

        # Detect Language
        detected_lang = detect_language(corrected_text)

        # Detect Emotion
        emotion = detect_emotion(corrected_text)

        # Translate Text (if not already in target language)
        translated_text = corrected_text
        if detected_lang != target_lang:
            translated_text = context_translate(corrected_text, detected_lang, target_lang)

        return jsonify({
            "original_text": user_text,
            "corrected_text": corrected_text,
            "emotion": emotion,
            "translated_text": translated_text
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/")
def home():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
